package inputValidation;

import java.util.Scanner;

public class InputValidation
{

	public static void main(String[] args) {
		
		//a positive even integer
		/*Scanner fromKeyboard = new Scanner(System.in);
	
		System.out.println("Insert any positive even integer: ");
		int x = fromKeyboard.nextInt();

        while(x % 2 == 1 || x < 0)
        {
            System.out.println("\n" + x + " is not a positive even integer.");
            
            System.out.print("Enter a number that is a even positive integer: ");
            x = fromKeyboard.nextInt();
            fromKeyboard.nextLine();
        }
        
        fromKeyboard.close();
        
        System.out.println(x + " is valid");
    }
		*/
		
		
		
		
		//a multiple of 4 and 5
		/*Scanner fromKeyboard = new Scanner(System.in);
		
		System.out.println("Insert any factor of 4 and 5: ");
		int x = fromKeyboard.nextInt();

        while(x % 4 != 0  || x % 5 != 0)
        {
            System.out.println("\n" + x + " is not a factor of 4 and 5.");
            
            System.out.print("Enter a number that is a factor of 4 and 5: ");
            x = fromKeyboard.nextInt();
            fromKeyboard.nextLine();
        }
        
        fromKeyboard.close();
        
        System.out.println(x + " is factor of 4 and 5!");
		*/
		
		
		
		
		
		
		
		
		//yes or no
		/*Scanner in = new Scanner(System.in);
		System.out.println("write 'yes' or 'no'"); 
		   String line = in.nextLine();
		   
		
		   while (! line.equals("yes") )
		   {
		   System.out.println("Feeling negative today?:/");
	       line = in.nextLine();	
		   }
		 
		   System.out.println("That's a good answer:)");
		   line = in.nextLine();
		*/
		
		
		
		
		
		
		
		
		//a single lowercase letter
		/*
		Scanner in = new Scanner(System.in);
		   System.out.println("Input a single letter"); 
		   String line = in.nextLine();
		   char c = line.charAt(0);
		   
		   while (Character.isLetter(c))
		   {
		   System.out.println(c +" Is a Letter");
		   }
		   
		    while( Character.isDigit(c))		   
		   {
		   System.out.println(c +" Is a digit. Please insert a single letter!!!");
		   line = in.nextLine();
		   c = line.charAt(0);
		   }
		*/
		

		 

		




		
	}
}



