package codingBatTester;

public class CodingBat
{
	public static void main(String[] args)
	{
	}

	
	public int countEvens(int[] nums) {
		 
		
		 int smallest = 0;
		  int largest = 0;
		  int difference = 0;
		  
		  
		  for (int i = 0; i < nums.length; i++)
		  {
		    smallest = Math.min(nums[0], nums[i]);
		    largest = Math.max(nums[0], nums[i]);
		    difference = largest - smallest;
		  }
		  return (difference);
		}
}



		  
