package cashRegister;

import java.text.NumberFormat;
import java.util.Scanner;

public class CashRegisterUI
{
    private static final double MIN_PRICE = 0;
    
    private Scanner fromKeyboard;
    private NumberFormat currencyFormatter;
    private CashRegister register;
    
    /**
     * Constructs a CashRegisterUI ready to start a transaction.
     */
    public CashRegisterUI()
    {
        fromKeyboard = new Scanner(System.in);
        currencyFormatter = NumberFormat.getCurrencyInstance();
        register = new CashRegister();
    }
    
    /**
     * Accepts a valid price from the user
     * or a blank line for no more items.
     * @return a valid price or -1 if no more items
     */
    double acceptValidPrice() // package access for testing
    {
        System.out.print("Enter price (leave blank if no more items): $");
        String input = fromKeyboard.nextLine();
        
        while(input.length() > 0 &&
                (!isDouble(input) || Double.parseDouble(input) < MIN_PRICE))
        {
            System.out.println();
            System.out.println("Error: Price must be at least " + currencyFormatter.format(MIN_PRICE));
            
            System.out.print("Enter price (leave blank if no more items): $");
            input = fromKeyboard.nextLine();
        }
        
        if(input.length() == 0)
        {
            return -1;
        }
     
        return Double.parseDouble(input);
    }
    
    /**
     * Accepts all items from the user.
     * Displays total when finished accepting items
     */
    void acceptAllItemsAndDisplayTotal() // package access for testing
    {	
    	double price = acceptValidPrice();
    	while (price >= 0)
    	{
    		register.addItem(price);
    		price = acceptValidPrice();
    	}
    	System.out.println(register.getTotal());
    	
    	if (price <= 0)
    	{
    		System.out.println("Error: Price must be at least $0.00");
    		System.out.print("Enter price (leave blank if no more items): $");
            String input = fromKeyboard.nextLine();
    	}
    }
    
    void acceptValidPaymentAndDisplayChange() // package access for testing
    {
    	System.out.print("Enter your payment: $");
    	double payment = fromKeyboard.nextDouble();
    	fromKeyboard.nextLine();
    	
    	while (payment < register.getTotal())
    	{
    		System.out.println("Error: Payment amount must be at least: $" + register.getTotal());
    		
    		System.out.print("Enter your payment: $");
        	payment = fromKeyboard.nextDouble();
        	fromKeyboard.nextLine();
    	}
    	
    	System.out.println("Change: $" + (payment-register.getTotal()));
    	
    }
    
    /**
     * Conducts a single transaction including accepting
     * items, accepting payment and making change.
     */
    public void conductTransaction()
    {
        System.out.println();
        acceptAllItemsAndDisplayTotal();
        acceptValidPaymentAndDisplayChange();
    }
    
    
    /**
     * Returns true if value can be parsed to a double, false otherwise.
     * @param value the value to check
     * @return true if value can be parsed to a double, false otherwise.
     */
    private static boolean isDouble(String value)
    {
        try
        {
            Double.parseDouble(value);
        }
        catch(NumberFormatException e)
        {
            return false;
        }
        
        return true;
    }
}
