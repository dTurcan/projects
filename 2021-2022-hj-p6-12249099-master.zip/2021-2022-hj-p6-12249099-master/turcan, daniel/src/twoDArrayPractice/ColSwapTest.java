package twoDArrayPractice;

import java.util.Arrays;

import junit.framework.TestCase;

public class ColSwapTest extends TestCase
{
    public void testColSwapRegular()
    {
        int[][] mat = new int[][]{
            {10, 9, 8, 7},
            {6, 5, 4, 3},
            {2, 1, -1, 0}
        };
        
        int colAIndex = 1, colBIndex = 3;
        
        int[][] expectedResult = new int[][]{
            {10, 7, 8, 9},
            {6, 3, 4, 5},
            {2, 0, -1, 1}
        };
        
        TwoDArrayPracticeCP.colSwap(mat, colAIndex, colBIndex);
        
        assertTrue(Arrays.deepEquals(mat, expectedResult));
    }
    
    public void testColSwapSameColumn()
    {
        int[][] mat = new int[][]{
            {1, 2, 3},
            {4, 5, 6}
        };
        
        int colAIndex = 1, colBIndex = 1;
        
        int[][] expectedResult = new int[][]{
            {1, 2, 3},
            {4, 5, 6}
        };
        
        TwoDArrayPracticeCP.colSwap(mat, colAIndex, colBIndex);
        
        assertTrue(Arrays.deepEquals(mat, expectedResult));
    }
}
