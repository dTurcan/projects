package twoDArrayPractice;

import junit.framework.TestCase;

public class SumRowTest extends TestCase
{
    public void testSumRowRegular()
    {
        int[][] mat = new int[][] {
            {4, 8, 2, 3}, // 17
            {9, 7, 1, 5}, // 22
            {8, 3, 6, 4}  // 21
        };
        
        
        int rowIndex = 0;
        int expectedResult = 17;
        int actualResult = TwoDArrayPracticeCP.sumRow(mat, rowIndex);
        
        assertTrue(expectedResult == actualResult);
        
        
        rowIndex = 1;
        expectedResult = 22;
        actualResult = TwoDArrayPracticeCP.sumRow(mat, rowIndex);
        
        assertTrue(expectedResult == actualResult);
        
        
        rowIndex = 2;
        expectedResult = 21;
        actualResult = TwoDArrayPracticeCP.sumRow(mat, rowIndex);
        
        assertTrue(expectedResult == actualResult);
    }
    
    public void testSumRowShort()
    {
        int[][] mat = new int[][] {
            {4},
            {6}
        };
        
        
        int rowIndex = 0;
        int expectedResult = 4;
        int actualResult = TwoDArrayPracticeCP.sumRow(mat, rowIndex);
        
        assertTrue(expectedResult == actualResult);
        
        
        rowIndex = 1;
        expectedResult = 6;
        actualResult = TwoDArrayPracticeCP.sumRow(mat, rowIndex);
        
        assertTrue(expectedResult == actualResult);
    }
    
    public void testSumRowEmpty()
    {
        int[][] mat = new int[][] {
            {}
        };
        
        int rowIndex = 0;
        int expectedResult = 0;
        int actualResult = TwoDArrayPracticeCP.sumRow(mat, rowIndex);
        
        assertTrue(expectedResult == actualResult);
    }
}
