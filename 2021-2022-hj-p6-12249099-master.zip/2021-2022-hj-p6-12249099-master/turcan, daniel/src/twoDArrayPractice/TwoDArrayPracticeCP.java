package twoDArrayPractice;

public class TwoDArrayPracticeCP
{
    /**
     * Swaps all values in the specified 2 rows of mat.
     * @param mat the array
     * @param rowAIndex the index of a row to be swapped
     * @param rowBIndex the index of a row to be swapped
     */
    public static void rowSwap(int[][] mat, int rowAIndex, int rowBIndex)
    {
    	int[] first = mat[rowAIndex];
		mat[rowAIndex] = mat[rowBIndex];
		mat[rowBIndex] = first;
    }
    
    /**
     * Swaps all values in the specified 2 columns of mat.
     * @param mat the array
     * @param colAIndex the index of a column to be swapped
     * @param colBIndex the index of a column to be swapped
     */
    public static void colSwap(int[][] mat, int colAIndex, int colBIndex)
    {
    	
    	for (int c = 0; c < mat.length; c++) {
    	    int first = mat[c][colAIndex];
    	    mat[c][colAIndex] = mat[c][colBIndex];
    	    mat[c][colBIndex] = first;
    	}
    	
    }
    

    /**
     * Returns an array with the specified number of rows and columns
     * containing the characters from str in row-major order. If str.length()
     * is greater than rows * cols, extra characters are ignored. If
     * str.length() is less than rows * cols, the remaining elements in the
     * returned array contain null.
     * 
     * @param str the string to be placed in an array
     * @param rows the number of rows in the array to be returned
     * @param cols the number of columns in the array to be returned
     * @return an array containing the characters from str in row-major order
     */
    public static String[][] fillRowMajor(String str, int rows, int cols)
    {
        return null; // TODO: implement
    }
    
    
    /**
     * Returns the sum of all values in the specified row of mat.
     * @param mat the array
     * @param rowIndex the index of the row to be summed
     * @return the sum of all values in the row
     */
    public static int sumRow(int[][] mat, int rowIndex)
    {
    	int sum = 0;
        
    	for (int r = 0; r < mat[rowIndex].length;r++)
        {
        	sum += mat[rowIndex][r];
        }
    	
        return sum;
    }
    
    /**
     * Returns the sum of all values in the specified column of mat.
     * @param mat the array
     * @param colIndex the index of the column to be summed
     * @return the sum of all values in the column
     */
    public static int sumCol(int[][] mat, int colIndex)
    {
    	int sum = 0;
    	for (int r = 0; r < mat.length; r++) {
    	    sum += mat[r][colIndex];
    	}
    	return sum;
    }
    
    /**
     * Returns the sum of all values in mat.
     * @param mat the array
     * @return the sum of all values in the array
     */
    public static int sumAll(int[][] mat)
    {
        int sum = 0;
        
        for (int r = 0; r < mat.length; r++) {
    	   for (int c = 0; c<mat[r].length;c++)
    	   {
    		   sum += mat[r][c];
    	   }
    	}
        
        return sum;
    }
}