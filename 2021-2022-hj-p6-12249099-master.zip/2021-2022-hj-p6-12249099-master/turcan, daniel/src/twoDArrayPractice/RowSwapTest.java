package twoDArrayPractice;

import java.util.Arrays;

import junit.framework.TestCase;

public class RowSwapTest extends TestCase
{
    public void testRowSwapRegular()
    {
        int[][] mat = new int[][]{
            {10, 9, 8, 7},
            {6, 5, 4, 3},
            {2, 1, -1, 0}
        };
        
        int rowAIndex = 1, rowBIndex = 2;
        
        int[][] expectedResult = new int[][]{
            {10, 9, 8, 7},
            {2, 1, -1, 0},
            {6, 5, 4, 3}
        };
        
        TwoDArrayPracticeCP.rowSwap(mat, rowAIndex, rowBIndex);
        
        assertTrue(Arrays.deepEquals(mat, expectedResult));
    }
    
    public void testRowSwapSameRow()
    {
        int[][] mat = new int[][] {
            {1, 2, 3},
            {4, 5, 6}
        };
        
        int rowAIndex = 1, rowBIndex = 1;
        
        int[][] expectedResult = new int[][] {
            {1, 2, 3},
            {4, 5, 6}
        };
        
        TwoDArrayPracticeCP.rowSwap(mat, rowAIndex, rowBIndex);
        
        assertTrue(Arrays.deepEquals(mat, expectedResult));
    }
}
