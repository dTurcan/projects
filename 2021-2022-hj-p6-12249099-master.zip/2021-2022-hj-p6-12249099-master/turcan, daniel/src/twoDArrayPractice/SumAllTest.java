package twoDArrayPractice;

import junit.framework.TestCase;

public class SumAllTest extends TestCase
{
    public void testSumAllRegular()
    {
        int[][] mat = new int[][] {
            {4, 8, 2, 3},
            {9, 7, 1, 5},
            {8, 3, 6, 4}
        };
        
        int expectedResult = 60;
        int actualResult = TwoDArrayPracticeCP.sumAll(mat);
        
        assertTrue(expectedResult == actualResult);
    }
    
    public void testSumAllShort()
    {
        int[][] mat = new int[][] {
            {4}
        };
        
        int expectedResult = 4;
        int actualResult = TwoDArrayPracticeCP.sumAll(mat);
        
        assertTrue(expectedResult == actualResult);
    }
    
    public void testSumAllEmpty()
    {
        int[][] mat = new int[][] {
            {}
        };
        
        int expectedResult = 0;
        int actualResult = TwoDArrayPracticeCP.sumAll(mat);
        
        assertTrue(expectedResult == actualResult);
    }
}
