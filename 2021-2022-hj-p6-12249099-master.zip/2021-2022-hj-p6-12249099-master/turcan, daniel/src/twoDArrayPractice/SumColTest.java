package twoDArrayPractice;

import junit.framework.TestCase;

public class SumColTest extends TestCase
{
    public void testSumColRegular()
    {
        int[][] mat = new int[][] {
            {4, 8, 2, 3},
            {9, 7, 1, 5},
            {8, 3, 6, 4}
        //   21 18 9  12
        };
        
        
        int colIndex = 0;
        int expectedResult = 21;
        int actualResult = TwoDArrayPracticeCP.sumCol(mat, colIndex);
        
        assertTrue(expectedResult == actualResult);
        
        
        colIndex = 1;
        expectedResult = 18;
        actualResult = TwoDArrayPracticeCP.sumCol(mat, colIndex);
        
        assertTrue(expectedResult == actualResult);
        
        
        colIndex = 2;
        expectedResult = 9;
        actualResult = TwoDArrayPracticeCP.sumCol(mat, colIndex);
        
        assertTrue(expectedResult == actualResult);
        
        
        colIndex = 3;
        expectedResult = 12;
        actualResult = TwoDArrayPracticeCP.sumCol(mat, colIndex);
        
        assertTrue(expectedResult == actualResult);
    }
    
    public void testSumColShort()
    {
        int[][] mat = new int[][] {
            {4, 6}
        };
        
        
        int colIndex = 0;
        int expectedResult = 4;
        int actualResult = TwoDArrayPracticeCP.sumCol(mat, colIndex);
        
        assertTrue(expectedResult == actualResult);
        
        
        colIndex = 1;
        expectedResult = 6;
        actualResult = TwoDArrayPracticeCP.sumCol(mat, colIndex);
        
        assertTrue(expectedResult == actualResult);
    }
}
