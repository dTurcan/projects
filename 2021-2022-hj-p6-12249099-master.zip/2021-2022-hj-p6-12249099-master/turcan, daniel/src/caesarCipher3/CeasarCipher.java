package caesarCipher3;


import java.util.Scanner;


public class CeasarCipher {

	public static void main(String[] args) {
		//System.out.println(decryptLetter('c', 2)); // a
		//System.out.println(decryptLetter('a', 2)); // y
		System.out.println(encryptPhrase("cd cd", 2)); // ab ab
		System.out.println(decryptPhrase("cd cd")); // ab ab


	}
	
	
	
	
    
	private static char decryptLetter(char letter, int key)
    {
        char resultLetter = (char) (letter - key);
        
        if(resultLetter < 'a')
            resultLetter = (char) (resultLetter + 26);
        
        return resultLetter;
    }
	
	
	
	public static String encryptPhrase(String phrase, int key)
	{
		String encryptedMessage = "";
		
		for(int i = 0; i < phrase.length(); i++)
		{
			if(isLetter(phrase.charAt(i)))
				encryptedMessage += decryptLetter(phrase.charAt(i), key);
			else
				encryptedMessage += phrase.charAt(i);
		}
		
		return encryptedMessage;
	}
	
	private static boolean isLetter(char letter)
	{
		return letter >= 'a' && letter <= 'z';
	}
	
	
	
	
	
	
	public static void String decryptPhrase(String phrase)
	{
		
		for(int key = 1; key <= 26; key++)
		{
			String decryptedPhrase = decryptMessage(encryptedMessage, key);
			System.out.println(decryptedPhrase);}
				
	}
	return (decryptedPhrase);

}


