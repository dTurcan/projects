package purchaseCalculator;

import java.util.Scanner;

public class Purchasecalc {

	public static void main(String[] args) 
	{
		Scanner fromKeyboard = new Scanner(System.in);
		System.out.println("Enter the amount of your loan: $");
		double amount = fromKeyboard.nextDouble();

		double state = amount / 25;
		System.out.println("State tax: $" + state);
		
		double county = amount / 50;
		System.out.println("State tax: $" + county);

		double totaltax = state + county;
		System.out.println("Total Sales tax: $" + totaltax);
		
		double totalsales = amount + totaltax;
		System.out.println("Total Sales: $" + totalsales);
		
		
	}	


}


