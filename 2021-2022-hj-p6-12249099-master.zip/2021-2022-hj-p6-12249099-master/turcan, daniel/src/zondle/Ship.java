package zondle;

import java.util.ArrayList;

import processing.core.PApplet;
import processing.core.PImage;

public class Ship 
{
	private PApplet parent;
	private int shipX, shipY;
	private PImage shipImage;
	private int turnAmount;
	private int speed;
	private int shipDiamater;
	
	private ArrayList<Shoot> bullets;
	
	public Ship(PApplet p, int shipX, int shipY, PImage shipImage)
	{
		parent = p;
		this.shipX = shipX;
		this.shipY = shipY;
		this.shipImage = shipImage;
		turnAmount = 90;
		speed = 3;
		bullets = new ArrayList<Shoot>();
		shipDiamater = 30;
	}
	
	public void drawShip() {
		parent.fill(255);

		parent.pushMatrix();

		parent.translate(shipX, shipY);
		parent.rotate(PApplet.radians(turnAmount));
		parent.imageMode(PApplet.CENTER);

		parent.image(shipImage, 0, 0);

		parent.popMatrix();
	}
	
	
	public void updateDirection(int newTurnAmount)
	{
		turnAmount = newTurnAmount;
	}
	
	
	public void updatePosition(boolean rightArrowPressed, boolean leftArrowPressed, boolean upArrowPressed, boolean downArrowPressed)
	{		
	    if(rightArrowPressed && shipX < parent.width - shipDiamater/2)
		{
			shipX= shipX + speed;
		}
		
		if(downArrowPressed && shipY < parent.height - shipDiamater/2)
		{
			shipY= shipY + speed;
		}
		
		if(upArrowPressed && shipY > 0 - shipDiamater/2)
		{
			shipY= shipY - speed;
		}

		if(leftArrowPressed && shipX > 0 + shipDiamater/2)
		{
			shipX= shipX - speed;
		}

		if(shipX-40 > parent.width)
		{
			shipX = -40;
		}
	}
	
	public void addShot()
	{

		if(turnAmount == 45)
			{
				bullets.add(new Shoot(parent, shipX + 5, shipY + 5, 10,-10));
			}
			else if(turnAmount == 315)
		
			{
				bullets.add(new Shoot (parent, shipX + 5, shipY + 5, -10,-10));
			}
			else if(turnAmount == 135)
			{
				bullets.add(new Shoot(parent, shipX + 5, shipY + 5, 10, 10));	
			}
			else if(turnAmount == 225)
			{
				bullets.add(new Shoot (parent, shipX + 5, shipY + 5, -10,10));
			}	
			else if(turnAmount == 180)
			{
				bullets.add(new Shoot (parent, shipX + 5, shipY + 5, 0,10));
			}
			else if(turnAmount == 0)
			{
				bullets.add(new Shoot (parent, shipX + 5, shipY + 5, 0,-10));
			}
			else if(turnAmount == 90)
			{
				bullets.add(new Shoot (parent, shipX + 5, shipY + 5, 10,0));
			} 
			else if(turnAmount == 270)
			{
				bullets.add(new Shoot (parent, shipX + 5, shipY + 5, -10,0));
			}
	}
	
	public void moveShots()
	{
		for (int i = 0; i < bullets.size(); i++)
			{
				bullets.get(i).drawShot();
				bullets.get(i).moveShot();
			}
	}
	
	
	public boolean detectHit(Ship otherShip)
	{
		for (int i = 0; i < bullets.size(); i++)
		{
			if (PApplet.dist(otherShip.shipX, otherShip.shipY, bullets.get(i).getCenterX(), bullets.get(i).getCenterY()) <= 40)
			{
//				System.out.println("Hit");
				return true;
			}
		}
		
		return false;
	}
}
