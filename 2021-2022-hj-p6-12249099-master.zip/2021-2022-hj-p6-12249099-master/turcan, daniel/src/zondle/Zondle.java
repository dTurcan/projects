package zondle;


import java.util.ArrayList;

import processing.core.PApplet;
import processing.core.PImage;

public class Zondle extends PApplet 
{
//	private int x, y, rotationDegrees;

	private boolean rightArrowPressed, downArrowPressed, leftArrowPressed, upArrowPressed;
	private boolean wPressed, aPressed, sPressed, dPressed; 
	private int shipOneFakeLives = 30;
	private int shipTwoFakeLives = 30;
	private int shipOneActualLives = 3;
	private int shipTwoActualLives = 3;
//	PImage shipOne;
//	PImage shipTwo;
//
//	  
//	int shipOneX = 100;
//	int shipOneY = 50;
//	int shipOneDiamater = 30;
//	int shipOneSpeed = 3;
//	int turnAmount = 90;
	

	//	private Shoot sh;
	
	private Ship shipOne;
	private Ship shipTwo;

	public static void main(String[] args) 
	{

		PApplet.main("zondle.Zondle");


	}

	public void settings()
	{
		size(800,600);
	}

	public void setup()
	{
		shipOne = new Ship(this, 50, 50, loadImage("images/rocket_1.png"));
		shipTwo = new Ship(this, 200, 50, loadImage("images/rocket_2.png"));
//		shipOne = ;
//		shipTwo = loadImage("images/rocket_2.png");
//		rotationDegrees = 45;

	}

	public void draw()
	{
		background(100,100,100);
		
		updateDirection();
		shipOne.drawShip();
		shipTwo.drawShip();
		
		playerMovement();
		shipOne.moveShots();
		shipTwo.moveShots();
		detectHit();
		
		textSize(20);
		text("Light Ship Lives: " + shipOneActualLives, 20,20);
		text("Dark Ship Lives: " + shipTwoActualLives, 20,50);
		
		
		if (shipOneActualLives == 0)
		{	
			textSize(50);
			fill(0);
			text("Dark Ship Won!!!", 200, 250);
		}
		
		if (shipTwoActualLives == 0)
		{	
			textSize(50);
			fill(0);
			text("Light Ship Won!!!", 200, 250);
		}
	}

	private void playerMovement() 
	{
		shipOne.updatePosition(rightArrowPressed, leftArrowPressed, upArrowPressed, downArrowPressed);
		shipTwo.updatePosition(dPressed, aPressed, wPressed, sPressed);
//		direction();
//
//
//		if(rightArrowPressed && shipOneX < width - shipOneDiamater/2)
//			shipOneX= shipOneX + shipOneSpeed;
//
//		if(downArrowPressed && shipOneY < height - shipOneDiamater/2)
//			shipOneY= shipOneY + shipOneSpeed;
//		
//		if(upArrowPressed && shipOneY > 0 - shipOneDiamater/2)
//			shipOneY= shipOneY - shipOneSpeed;
//
//		if(leftArrowPressed && shipOneX > 0 + shipOneDiamater/2)
//			shipOneX= shipOneX - shipOneSpeed;
//
//
//		if(shipOneX-40 > width)
//		{
//			shipOneX = -40;
//		}
	}

	private void updateDirection() {
		if (upArrowPressed && rightArrowPressed) {
//			turnAmount = 45;
			shipOne.updateDirection(45);
		}
		else if (downArrowPressed && rightArrowPressed) {
			//turnAmount = 135;
			shipOne.updateDirection(135);
		}
		else if (downArrowPressed && leftArrowPressed) {
			//turnAmount = 225;
			shipOne.updateDirection(225);
		}
		else if (upArrowPressed && leftArrowPressed) {
			//turnAmount = 315;
			shipOne.updateDirection(315);
		}
		else if(rightArrowPressed)
		{
			//turnAmount = 90;
			shipOne.updateDirection(90);
		}
		else if(downArrowPressed)
		{
			//turnAmount = 180;
			shipOne.updateDirection(180);
		}
		else if (leftArrowPressed) 
		{
			//turnAmount = 270;
			shipOne.updateDirection(270);
		}
		else if (upArrowPressed)
		{
			//turnAmount = 0;
			shipOne.updateDirection(0);
		}
		
		else {
			if (wPressed && dPressed) {
//				turnAmount = 45;
				shipTwo.updateDirection(45);
			}
			else if (sPressed && dPressed) {
				//turnAmount = 135;
				shipTwo.updateDirection(135);
			}
			else if (sPressed && aPressed) {
				//turnAmount = 225;
				shipTwo.updateDirection(225);
			}
			else if (wPressed && aPressed) {
				//turnAmount = 315;
				shipTwo.updateDirection(315);
			}
			else if(dPressed)
			{
				//turnAmount = 90;
				shipTwo.updateDirection(90);
			}
			else if(sPressed)
			{
				//turnAmount = 180;
				shipTwo.updateDirection(180);
			}
			else if (aPressed) 
			{
				//turnAmount = 270;
				shipTwo.updateDirection(270);
			}
			else if (wPressed)
			{
				//turnAmount = 0;
				shipTwo.updateDirection(0);
			}
		}
	}
	
	public void mousePressed()
	{
		shipOne.addShot();
	}
	
	public void keyPressed()
	{
		
		if(key == CODED)
		{

			if(keyCode == RIGHT)
			{
				rightArrowPressed = true;
			}
			else if(keyCode == DOWN)
			{
				downArrowPressed = true;
			}
			else if (keyCode == LEFT) 
			{
				leftArrowPressed = true;
			}
			else if (keyCode == UP)
			{
				upArrowPressed = true;
			}
		}
		else
		{
			if(key == 'w' || key == 'W')
			{
				wPressed = true;
			}
			else if(key == 'a' || key == 'A')
			{
				aPressed = true;
			}
			else if(key == 'd' || key == 'D')
			{
				dPressed = true;
			}
			else if(key == 's' || key == 'S')
			{
				sPressed = true;
			}
		}
		
		if (key == ' ')
		{
			shipTwo.addShot();
		}
		
		
}

	public void keyReleased()
	{
		if(key == CODED)
		{
			if(keyCode == RIGHT)
				rightArrowPressed = false;
			else if(keyCode == DOWN)
				downArrowPressed = false;
			else if (keyCode == LEFT)
				leftArrowPressed = false;
			else if (keyCode == UP)
				upArrowPressed = false;
		}
		else
		{
			if(key == 'w' || key == 'W')
			{
				wPressed = false;
			}
			else if(key == 'a' || key == 'A')
			{
				aPressed = false;
			}
			else if(key == 'd' || key == 'D')
			{
				dPressed = false;
			}
			else if(key == 's' || key == 'S')
			{
				sPressed = false;
			}
		}


	}
	
	public void detectHit()
	{
		if(shipOne.detectHit(shipTwo) == true)
		{
			shipTwoFakeLives -= 1;
			System.out.println(shipTwoFakeLives);
		}
		if(shipTwo.detectHit(shipOne) == true)
		{
			shipOneFakeLives -= 1;		 
			System.out.println(shipOneFakeLives);
		}
		
		if (shipOneFakeLives == 23)
		{
			shipOneActualLives --;
		}
		else if (shipOneFakeLives == 16)
		{
			shipOneActualLives --; 
		}
		else if (shipOneFakeLives == 9)
		{
			shipOneActualLives --; 
		}
		
		if (shipTwoFakeLives == 23)
		{
			shipTwoActualLives --;
		}
		else if (shipTwoFakeLives == 16)
		{
			shipTwoActualLives --; 
		}
		else if (shipTwoFakeLives == 9)
		{
			shipTwoActualLives --; 
		}
	}
}


