package loopPractice;

import java.util.Scanner;

public class LoopPracticeBetter
{

	public static void main(String[] args)
	{
		// TODO Auto-generated method stub
		System.out.println(isPrime(15)); // false
		System.out.println(isPrime(13)); // true
	}

	public static boolean isPrime(int number)
	{

		int counter = 0;
		for (int i = 1; i <= number; i++)
		{
			if(number % i == 0)
			{
				counter ++;	
			}
		}
		if (counter == 2)
		{
			//				 System.out.println("true");
			return true;
		}
		else
		{
			//				System.out.println("false");
			return false;
		}
	}
	
	public static void exercise21(int number)
	{
		for(int i = 0; i < number; i++)
		{
			
		}
	}
}


