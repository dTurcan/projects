package loopPractice;

public class LoopPractice {
	public static void main(String[] args) {
	
		
	/* SOLUTION TO 14
	 for(int i = 0; i <= 100; i++)
	{
		if (i % 2 != 0)
		{
			System.out.println(i);
		}
	}
	*/
		
		/* SOLUTION TO 15
		for(int i = 300; i > 0; i--)
		{
			if (i % 3 == 0)
			{
				System.out.println(i);
			}
		}
		*/
		
		
		/* SOLUTION 16
		int low = 20;
		int high = 60;
		for (int i = low; i <= high; i++)
		{
			if (i % 4 == 0 && i % 5 != 0)
			{
				System.out.println(i);
			}
		}
		*/
		
		
		/* SOLUTION 17
		 int number = 100;
		for (int i = 1; i <= number; i++)
		{
			if (number % i == 0)
			{
				System.out.println(i);
			}
		}
		*/
		
		/* SOLUTION 18
		int lines = 4;
		String test = "";
		for (int i = 0; i <= lines; i++)
		 {
			System.out.print(test);
			System.out.println("*");
			test = test + " ";
		 }
		 */
		
		/* SOLUTION 19
		int heads = 0;
		int tails = 0;
		for (int i = 0; i <= 99; i++)
		{
			int flip = (int) (Math.random() * 2);
			
			if (flip == 0)
			{
				heads ++;
			}
			else
			{
				tails++;
			}
		}
		System.out.println("heads:" + heads);
		System.out.println("tails:" + tails);
		*/
		
		
		
		 /*SOLUTION 20
		int number = 40;
		int counter = 0;
		for (int i = 1; i <= number; i++)
		{
			if(number % i == 0)
			{
				counter ++;	
			}
		}
			if (counter == 2)
			{
				System.out.print("Prime");
			}
			else
			{
				System.out.print("Not Prime");
			}
		}
		*/
	
		int num = 50;
		int counter = 0;
		
		for (int factor = 0, i = 2; factor <= num; factor++)
		{
			if(factor % i == 0)
			{
				counter = factor;	
				
				if (counter > 0)
			{
				System.out.println("" + factor + " is a prime factor of " + num);
			}
				
			}
		}
			
		}
	}










