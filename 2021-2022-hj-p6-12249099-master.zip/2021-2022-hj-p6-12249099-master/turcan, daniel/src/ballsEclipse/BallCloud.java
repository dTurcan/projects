package ballsEclipse;

import processing.core.PApplet;

public class BallCloud extends PApplet
{

	Ball[] balls;
	int clicked = 0;

	public static void main(String[] args) 
	{

		PApplet.main("ballsEclipse.BallCloud");
	}

	public void settings()
	{
		size(1000, 1000);
	}

	public void setup()
	{


		balls = new Ball[20000];

	}


	public void draw()
	{
		background(250,250,250);


		for (int i = 0; i < clicked; i++)
		{
			balls[i].drawBall();
			balls[i].moveBall();
		}


	}



	public void mousePressed()
	{
		for (int i = 0; i < 100; i++)
		{
			balls[clicked] = new Ball(this, mouseX , mouseY);
			clicked++;
		}
		
	}

}
