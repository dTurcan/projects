package ballsEclipse;

import processing.core.PApplet;

public class Ball
{
	private PApplet parent;

	private int topLeftX, topLeftY;
	private int ballColor;

	private int speedX, speedY;
	private int size;

	public Ball(PApplet p, int tLX, int tLY)
	{
		parent = p;

		topLeftX = tLX;
		topLeftY = tLY;
		ballColor = parent.color(parent.random(255), parent.random(255), parent.random(255));
		speedX = (int) parent.random(1,4);
		speedY = (int) parent.random(1,4);
		size = (int) parent.random(10,45);
	}

	public void moveBall()
	{
		topLeftX += speedX;
		topLeftY += speedY;

		if (topLeftX >= 980)
		{
			topLeftX = 980;
			speedX = -speedX;
		}
		else if (topLeftX <= 20)
		{
			topLeftX = 20;
			speedX = -speedX;
		}


		if (topLeftY >= 980)
		{
			topLeftY = 980;
			speedY = -speedY;
		}
		else if (topLeftY <= 20)
		{
			topLeftY = 20;
			speedY = - speedY;
		}
	}

	public void drawBall()
	{
		parent.fill(ballColor);
		parent.ellipse(topLeftX, topLeftY, size, size);
	}
}
