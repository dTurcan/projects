package aimTrainer;

import processing.core.PApplet;

public class AimTrainer extends PApplet
{

	public static void main(String[] args)
	{
		PApplet.main("aimTrainer.AimTrainer");
	}

	public void settings()
	{
		size(700,800);
	}
	
	public void setup()
	{
		
	}


	public void draw()
	{
		
		
		drawMole(1);
		

		 
		 if (mousePressed) {
		      if (mouseX >= 180 && mouseX <= 180+154 && mouseY >= 320 && mouseY <= 320+76)
		      {
		    
		      background(0,0,0);
		      } 
		      else if (mouseX >= 70 && mouseX <= 70+76 && mouseY >= 200 && mouseY <= 200+154) 
		      {
		       background(250,0,0); 
		      } 
		      else if (mouseX >= 180 && mouseX <= 180+154 && mouseY >= 160 && mouseY <= 160+76) 
		      {
		      background(0,250,0);
		      } 
		      else if (mouseX >= 350 && mouseX <= 350+76 && mouseY >= 200 && mouseY <= 200+154) 
		      {
		       background(250,0,0);
		      }
		    }
	}
	
	public void drawMole(int moleNumber)
	{
		fill(200, 200, 200);
	    rect( 180, 320, 154, 76);

	    fill(200, 200, 200);
	    rect( 70, 200, 76, 154);

	    fill(200, 200, 200);
	    rect( 180, 160, 154, 76);

	    fill(200, 200, 200);
	    rect( 350, 200, 76, 154);
	    System.out.println("hello world");
	}
	
	

	
	
}
