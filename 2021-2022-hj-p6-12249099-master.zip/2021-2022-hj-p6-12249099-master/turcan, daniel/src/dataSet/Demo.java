package dataSet;

public class Demo {

	public static void main(String[] args) {
		
//		DataSet d1 = new DataSet(7);
//		d1.addValue(4);
//		System.out.println(d1.getSum()); //11
//		d1.addValue(2);
//		System.out.println(d1.getSum()); //16
//		System.out.println(d1.getAverage()); //
		
		DataSet d2 = new DataSet();
		d2.addValue(4);
		System.out.println(d2.getSum()); //4
		d2.addValue(2);
		System.out.println(d2.getSum()); //6
		System.out.println(d2.getAverage());//3
	}

}
