package dataSet;

public class DataSet
{
	
	private double total;
	private int addedNumbers;
	
	public DataSet() 
	{
		total = 0;
		addedNumbers = 0;
	}
	
	public DataSet(int value)
	{
		total = value;
		addedNumbers = 1;
	}
	
	public void addValue(int value)
	{
		total += value;
		addedNumbers ++;
	}
	
	public int getSum()
	{
		return (int) total; 
	}
	
	public double getAverage()
	{
		
		return total / addedNumbers;
	}
}



