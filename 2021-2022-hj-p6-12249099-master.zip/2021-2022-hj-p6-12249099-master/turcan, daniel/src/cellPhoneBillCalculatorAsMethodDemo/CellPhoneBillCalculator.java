package cellPhoneBillCalculatorAsMethodDemo;

import java.text.NumberFormat;
import java.util.Scanner;

/*
 * Plan 1:
 *  - $9.95 / month
 *  - 30 minutes
 *  - $0.25 / additional minute
 *  - 30 text messages
 *  - $0.20 / additional message
 *  
 * Plan 2:
 *  - $14.95 / month
 *  - 100 minutes
 *  - $0.10 / additional minute
 *  - 100 text messages
 *  - $0.20 / additional message
 * 
 * Plan 3:
 *  - $19.95 / month
 *  - 400 minutes
 *  - $0.10 / additional minute
 *  - unlimited messages
 *  
 * Plan 4:
 *  - $29.95 / month
 *  - unlimited minutes
 *  - unlimited messages
 */

public class CellPhoneBillCalculator
{
	private static Scanner fromKeyboard = new Scanner(System.in);
	
    public static void main(String[] args)
    {
        //calculatePhoneBill();
    	calcBestPlan();
    }
    
    // -1 if no max value
    public static int getValidInput(String prompt, int minValue, int maxValue)
    {
        System.out.print(prompt + ": ");
        int input = fromKeyboard.nextInt();
        fromKeyboard.nextLine();
        
        while(input < minValue || (maxValue != -1 && input > maxValue))
        {
            System.out.println("Invalid input");
            System.out.print(prompt + ": ");
            input = fromKeyboard.nextInt();
            fromKeyboard.nextLine();
        }
        
        return input;
    }
    
    public static void calculatePhoneBill()
    {
        NumberFormat formatter = NumberFormat.getCurrencyInstance();
        
        int plan = getValidInput("Plan (1, 2, 3, or 4)", 1, 4);
        int minutesUsed = getValidInput("Minutes used", 0, -1);
        int messagesUsed = getValidInput("Messages used", 0, -1);
        
        
        double bill = calculateBill(plan, minutesUsed, messagesUsed);
        System.out.println("Bill: " + formatter.format(bill));
    }
    
    public static double calculateBill(int plan, int minutesUsed, int messagesUsed)
    {
        // defaults to Plan 1
        double baseRate = 9.95;
        int minutesIncluded = 30;
        int messagesIncluded = 30;
        double additionalMinuteRate = 0.25;
        double additionalMessageRate = 0.20;
        
        if(plan == 2)
        {
            baseRate = 14.95;
            minutesIncluded = 100;
            messagesIncluded = 100;
            additionalMinuteRate = 0.10;
            additionalMessageRate = 0.20;
        }
        else if(plan == 3)
        {
            baseRate = 19.95;
            minutesIncluded = 400;
            messagesIncluded =+
            		-1; // unlimited
            additionalMinuteRate = 0.10;
            additionalMessageRate = 0.00; // unlimited
        }
        else if(plan == 4)
        {
            baseRate = 29.95;
            minutesIncluded = -1; // unlimited
            messagesIncluded = -1; // unlimited
            additionalMinuteRate = 0.00; // unlimited
            additionalMessageRate = 0.00; // unlimited
        }
        
        double bill = baseRate;
        
        if(minutesIncluded != -1 && minutesUsed > minutesIncluded)
            bill += (minutesUsed - minutesIncluded) * additionalMinuteRate;
        
        if(messagesIncluded != -1 && messagesUsed > messagesIncluded)
            bill += (messagesUsed - messagesIncluded) * additionalMessageRate;
        
        return bill;
    }

    public static void calcBestPlan()
    {
    	int bestPlan = 1;
    	NumberFormat formatter = NumberFormat.getCurrencyInstance();
    	//take the total of what each plan costs
    	int minutesUsed = getValidInput("Expected Minutes", 0, -1);
    	int messagesUsed = getValidInput("Expected Messages", 0, -1);

    	for (int i = 1; i <=4; i++)
    	{
    		double bill = calculateBill(i, minutesUsed, messagesUsed);
    		System.out.println("Plan " + i + " Bill: " + formatter.format(bill));
    		
    		
    		double bestCostSoFar = calculateBill(bestPlan, minutesUsed, messagesUsed);
    	
    		if (bill < bestCostSoFar)
        	{
    			bestPlan = i;
        	}
    		System.out.println("Best plan is plan " + bestPlan);
    	}
    	
    	
    	


    	
    }
}




