package trafficLight;

import processing.core.PApplet;

public class Light extends PApplet
{
	private traffic one, two;
	private final int CHANGE_DELAY = 2000;
	private int timeOfNextChange;
	
	public static void main(String[] args) {
		PApplet.main("trafficLight.Light");
	}
	
	public void settings()
	{
		size(500,500);
	}
	
	public void setup()
	{
		one = new traffic(this, 10,10, 1);
		two = new traffic(this, 200,100, 4);
		timeOfNextChange = CHANGE_DELAY;
	}
	
	public void draw()
	{
		background(255);
		one.drawLight();
		two.drawLight();
		updateLight();
	}
    
	public void updateLight()
    {
		if(millis() >= timeOfNextChange)
		{
	    	one.change();
	    	two.change();
	    	timeOfNextChange = millis() + CHANGE_DELAY;
		}
    }
}



