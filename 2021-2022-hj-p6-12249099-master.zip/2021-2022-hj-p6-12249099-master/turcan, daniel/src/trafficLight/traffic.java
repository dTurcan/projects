package trafficLight;

import processing.core.PApplet;

public class traffic
{
	private PApplet parent;
	private int x, y;
	
	// 1: red - 2: yellow - 3: green - 4: red
	private int color;
	
    public traffic(PApplet p, int initX, int initY, int order)
    {
        parent = p;
        x = initX;
        y = initY;
        color = order;
        
    }
    
    public void drawLight()
	{
    	
    	parent.fill(50,50,50);
		parent.rect(x+50,y+50,70,140);
		parent.fill(255);
		parent.ellipse(x+85,y+75,40,40);
		parent.ellipse(x+85,y+120,40,40);
		parent.ellipse(x+85,y+165,40,40);
		
		if(color == 1) //red
		{
			parent.fill(255, 0, 0);
			parent.ellipse(x+85, y+75, 40, 40);
//			parent.fill(255, 255, 0);
		}
		else if(color == 2) //red
		{
			parent.fill(255, 0, 0);
			parent.ellipse(x+85, y+75, 40, 40);
//			parent.fill(255, 0, 0);
		}else if(color == 3) //red
		{
			parent.fill(255, 0, 0);
			parent.ellipse(x+85, y+75, 40, 40);
//			parent.fill(255, 0, 0);
		}else if(color == 4) //red
		{
			parent.fill(255, 0, 0);
			parent.ellipse(x+85, y+75, 40, 40);
//			parent.fill(255, 0, 0);
		}
		else if(color == 5) //green
		{
			parent.fill(0, 255, 0);
			parent.ellipse(x+85, y+165, 40, 40);
//			parent.fill(0, 255, 0);
		} 
		else if(color == 6) //yellow
		{
			parent.fill(255, 255, 0);
			parent.ellipse(x+85, y+120, 40, 40);
//			parent.fill(255, 255, 0);
		}

	}
    
    public void change()
    {
    	color++;
    	if(color == 7)
    	{
    		color = 1;
    	}
    }

}
