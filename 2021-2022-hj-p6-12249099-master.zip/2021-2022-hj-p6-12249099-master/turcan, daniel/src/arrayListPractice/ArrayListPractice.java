<<<<<<< HEAD
package arrayListPractice;

import java.util.ArrayList;

public class ArrayListPractice
{
    /**
     * Removes all occurrences of wordToRemove from words
     * @param words the list from which to remove word
     * @param wordToRemove the word to remove
     */
    public static void removeWord(ArrayList<String> words, String wordToRemove)
    {
        for (int i = 0; i < words.size(); i++)
        {
        	if (words.get(i).equals(wordToRemove))
        	{
        		words.remove(i);
        		i--;
        	}
        }
    }
    
    /**
     * Duplicates each element in list that matches elem. Each duplicate
     * element is adjacent to the original element. 
     * @param list the list from which to duplicate elements
     * @param elem the element to duplicate
     */
    public static void duplicateMatching(ArrayList<Integer> list, Integer elem)
    {
    	for (int i = 0; i < list.size(); i++)
    	{
    		if (list.get(i).equals(elem))
    		{
    			list.add(i, elem);
    			i++;
    		}
    	}
    }
    
    /**
     * Removes all adjacent duplicate elements from list.
     * 
     * For example, if list was:
     * [5, 7, 7, 5, 3, 7, 7, 7, 8, 7, 7, 7, 7]
     * 
     * list would become:
     * [5, 7, 5, 3, 7, 8, 7]
     * 
     * @param list the list from which to remove elements
     */
    public static void removeAdjacentDuplicates(ArrayList<Integer> list)
    {
    	
    	for (int i = list.size() - 1 ; i > 0; i--)
    	{
    		if (list.get(i).equals(list.get(i - 1)))
    		{
    			list.remove(i);
    			i = list.size();
    		}
    	}
    	
    }
    
    
    public void newClass() {
    	ArrayList<Integer> nums = new ArrayList<Integer>();
    	ArrayList<Integer> newNums = new ArrayList<Integer>();
    	nums.add(2);
    	nums.add(4);
    	nums.add(1);
    	nums.add(9);
        nums.add(16);
        nums.add(10);
        nums.add(51);
        nums.add(21);
       
        for (int i = 0; i <nums.size(); i++)
        {
        	if (nums.get(i) % 2 == 0)
        	{
        		newNums.add(nums.get(i));
        	}
        		
        }
        
        System.out.println(newNums);
    	}
}














=======
package arrayListPractice;

import java.util.ArrayList;

public class ArrayListPractice
{
    /**
     * Removes all occurrences of wordToRemove from words
     * @param words the list from which to remove word
     * @param wordToRemove the word to remove
     */
    public static void removeWord(ArrayList<String> words, String wordToRemove)
    {
        for (int i = 0; i < words.size(); i++)
        {
        	if (words.get(i).equals(wordToRemove))
        	{
        		words.remove(i);
        		i--;
        	}
        }
    }
    
    /**
     * Duplicates each element in list that matches elem. Each duplicate
     * element is adjacent to the original element. 
     * @param list the list from which to duplicate elements
     * @param elem the element to duplicate
     */
    public static void duplicateMatching(ArrayList<Integer> list, Integer elem)
    {
    	for (int i = 0; i < list.size(); i++)
    	{
    		if (list.get(i).equals(elem))
    		{
    			list.add(i, elem);
    			i++;
    		}
    	}
    }
    
    /**
     * Removes all adjacent duplicate elements from list.
     * 
     * For example, if list was:
     * [5, 7, 7, 5, 3, 7, 7, 7, 8, 7, 7, 7, 7]
     * 
     * list would become:
     * [5, 7, 5, 3, 7, 8, 7]
     * 
     * @param list the list from which to remove elements
     */
    public static void removeAdjacentDuplicates(ArrayList<Integer> list)
    {
    	
    	for (int i = list.size() - 1 ; i > 0; i--)
    	{
    		if (list.get(i).equals(list.get(i - 1)))
    		{
    			list.remove(i);
    			i = list.size();
    		}
    	}
    	
    }
    
    
    public void newClass() {
    	ArrayList<Integer> nums = new ArrayList<Integer>();
    	ArrayList<Integer> newNums = new ArrayList<Integer>();
    	nums.add(2);
    	nums.add(4);
    	nums.add(1);
    	nums.add(9);
        nums.add(16);
        nums.add(10);
        nums.add(51);
        nums.add(21);
       
        for (int i = 0; i <nums.size(); i++)
        {
        	if (nums.get(i) % 2 == 0)
        	{
        		newNums.add(nums.get(i));
        	}
        		
        }
        
        System.out.println(newNums);
    	}
}
>>>>>>> branch 'master' of git@github.com:WHHS-AP-CS/2021-2022-hj-p6-12249099.git
