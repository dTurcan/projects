package arrayPractice;

import java.util.Arrays;

import junit.framework.TestCase;

public class SwapTest extends TestCase
{
	public void testSwapWithRegularArrays()
	{
		int[] vals = {5, 9, 4};
		ArrayPractice.swap(vals, 0, 2);
		
		int[] expectedResult = {4, 9, 5};
		assertTrue(Arrays.equals(vals, expectedResult));
		
		
		vals = new int[] {5, 9, 4};
		ArrayPractice.swap(vals, 2, 1);
		
		expectedResult = new int[]{5, 4, 9};
		assertTrue(Arrays.equals(vals, expectedResult));
	}
	
	public void testSwapWithSelf()
	{
		int[] vals = {5, 9, 4};
		ArrayPractice.swap(vals, 1, 1);
		
		int[] expectedResult = {5, 9, 4};
		assertTrue(Arrays.equals(vals, expectedResult));
	}
	
	public void testSwapWithShortArray()
	{
		int[] vals = {5};
		ArrayPractice.swap(vals, 0, 0);
		
		int[] expectedResult = {5};
		assertTrue(Arrays.equals(vals, expectedResult));
	}
}
