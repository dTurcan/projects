package arrayPractice;

import java.util.Arrays;

import junit.framework.TestCase;

public class ReverseTest extends TestCase
{
	public void testReverseOnArrayWithEvenLength()
	{
		int[] vals = {1, 2, 3, 4, 5, 6};
		ArrayPractice.reverse(vals);
		
		int[] expectedResult = {6, 5, 4, 3, 2, 1};
		assertTrue(Arrays.equals(vals, expectedResult));
	}
	
	public void testReverseOnArrayWithOddLength()
	{
		int[] vals = {1, 2, 3, 4, 5};
		ArrayPractice.reverse(vals);
		
		int[] expectedResult = {5, 4, 3, 2, 1};
		assertTrue(Arrays.equals(vals, expectedResult));
	}
	
	public void testReverseOnShortArray()
	{
		int[] vals = {1};
		ArrayPractice.reverse(vals);
		
		int[] expectedResult = {1};
		assertTrue(Arrays.equals(vals, expectedResult));
	}
	
	public void testReverseOnEmptyArray()
	{
		int[] vals = {};
		ArrayPractice.reverse(vals);
		
		int[] expectedResult = {};
		assertTrue(Arrays.equals(vals, expectedResult));
	}
	
	public void testReverseOnRandomlyGeneratedArrays()
	{
		final int length = (int) (Math.random() * 91) + 10;
		
		int[] vals = new int[length];
		int[] expectedResult = new int[length];
		
		for(int i = 0; i < vals.length; i++)
		{
			int val = (int) (Math.random() * 100);
			vals[i] = val;
			expectedResult[expectedResult.length - 1 - i] = val;
		}
		
		ArrayPractice.reverse(vals);
		assertTrue(Arrays.equals(vals, expectedResult));
	}
}
