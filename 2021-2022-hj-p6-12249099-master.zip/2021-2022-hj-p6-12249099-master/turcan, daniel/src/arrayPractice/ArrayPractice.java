package arrayPractice;

public class ArrayPractice
{
	/**
	 * Swaps the elements at the specified indexes in arr
	 * @param arr the array
	 * @param index1 the index of an element to be swapped
	 * @param index2 the index of an element to be swapped
	 */
	public static void swap(int[] arr, int index1, int index2)
    {
		int first = arr[index1];
		arr[index1] = arr[index2];
		arr[index2] = first;
    }
	
	/**
     * Returns the sum of the elements in the specified array.
     * @param arr the array
     * @return the sum of the elements in the array
     */
    public static int findSum(int[] arr)
    {
    	int sum = 0;
        for (int i = 0; i < arr.length;i++)
        {
        	sum += arr[i];
        }
        return sum;
    }
    
    /**
     * Returns true if the specified arrays are the same length
     * and contain the same elements in the same order, false otherwise.
     */
    public static boolean areSame(int[] arr1, int[] arr2)
    {
    	if(arr1.length != arr2.length)
    	{
    		return false;
    	}
    	
		for(int i = 0; i < arr1.length; i++)
		{
			if (arr1[i] != arr2[i])
			{
				return false;
			}
		}
    	
        return true;
    }

    /**
     * Reverses the order of the elements in the array
     * @param arr the array
     */
    public static void reverse(int[] arr)
    {
    	for (int i = 0; i < arr.length/2; i++)
    	{
    		swap(arr, i, arr.length - 1 - i);
    	}
    	
    }
}
