package faceQuizPrep;

import processing.core.PApplet;


public class Main extends PApplet
{
	private Mouth mOne;
	private Eye Eone, Etwo;
	
	
	public static void main(String[] args) {
		PApplet.main("faceQuizPrep.Main");
		
	}

	public void settings()
	{
		size(500,500);
	}
	
	public void setup()
	{
		mOne = new Mouth(this, width/2,height/2 + 40);
		Eone = new Eye(this, width/2 - 40,height/2 - 50);
		Etwo = new Eye(this, width/2 + 40,height/2 - 50);
	}
	
	public void draw()
	{
		updateFace();
		background(255);
		fill(255);
		ellipse(width/2,height/2,200,200);
		mOne.drawMouth();
		Eone.drawEye();
		Etwo.drawEye();
		
		
	}
    
	public void updateFace()
    {
		Eone.setPupilDirection(Eye.LEFT);
		Etwo.setPupilDirection(2);
		mOne.setExpression(3);
    }
	
	
}
