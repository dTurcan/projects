package faceQuizPrep;

import processing.core.PApplet;

public class Mouth
{
    public static final int SMILE = 1, FROWN = 2, STRAIGHT = 3, TONGUE = 4;
    
    private final int WIDTH = 100;
    
    private PApplet parent;
    private int centerX, centerY;
    
    // SMILE, FROWN, STRAIGHT, or TONGUE
    private int expression;
    
    /**
     * Constructs a new Mouth
     * @param p the parent
     * @param centerX the x coordinate of the center
     * @param centerY the y coordinate of the center
     */
    public Mouth(PApplet p, int centerX, int centerY)
    {
        parent = p;
        this.centerX = centerX;
        this.centerY = centerY;
        expression = SMILE;
    }
    
    /**
     * Draws this mouth
     */
    public void drawMouth()
    {
        parent.noFill();
        parent.stroke(0);
        parent.strokeWeight(2);
        
        if(expression == SMILE)
            parent.arc(centerX, centerY, WIDTH, WIDTH / 3, PApplet.radians(0), PApplet.radians(180));
        else if(expression == FROWN)
            parent.arc(centerX, centerY, WIDTH, WIDTH / 3, PApplet.radians(180), PApplet.radians(360));
        else if(expression == STRAIGHT || expression == TONGUE)
        {
            parent.line(centerX - WIDTH / 2, centerY, centerX + WIDTH / 2, centerY);
            
            parent.fill(255, 0, 0);
            parent.noStroke();
            if(expression == TONGUE)
                parent.arc(centerX + WIDTH / 4, centerY, WIDTH / 5, WIDTH / 3, PApplet.radians(0), PApplet.radians(180));
        }
    }
    
    /**
     * Sets the expression of this mouth
     * @param expression SMILE, FROWN, STRAIGHT, or TONGUE
     */
    public void setExpression(int expression)
    {
        if(expression != SMILE && expression != FROWN &&
                expression != STRAIGHT && expression != TONGUE)
            throw new IllegalArgumentException("expression must be one of SMILE, FROWN, STRAIGHT, or TONGUE");
        
        this.expression = expression;
    }
}
