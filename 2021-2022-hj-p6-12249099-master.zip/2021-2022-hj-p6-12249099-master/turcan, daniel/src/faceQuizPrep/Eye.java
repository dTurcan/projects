package faceQuizPrep;

import processing.core.PApplet;

public class Eye
{
    public static final int STRAIGHT_AHEAD = 1, LEFT = 2, RIGHT = 3, DOWN = 4;
    
    private final int DIAMETER = 50;
    
    private PApplet parent;
    private int centerX, centerY;
    
    // STRAIGHT_AHEAD, LEFT, RIGHT, or DOWN
    private int pupilDirection;
    
    /**
     * Constructs a new Eye
     * @param p the parent
     * @param centerX the x coordinate of the center
     * @param centerY the y coordinate of the center
     */
    public Eye(PApplet p, int centerX, int centerY)
    {
        parent = p;
        this.centerX = centerX;
        this.centerY = centerY;
        pupilDirection = STRAIGHT_AHEAD;
    }
    
    /**
     * Draws this eye
     */
    public void drawEye()
    {
        parent.noStroke();
        parent.ellipseMode(PApplet.CENTER);
        
        // outer eye
        parent.fill(52, 225, 235);
        parent.ellipse(centerX, centerY, DIAMETER, DIAMETER);
        
        // pupil
        int pupilCenterX = centerX, pupilCenterY = centerY;
        if(pupilDirection == LEFT)
            pupilCenterX = centerX - DIAMETER / 4;
        else if(pupilDirection == RIGHT)
            pupilCenterX = centerX + DIAMETER / 4;
        else if(pupilDirection == DOWN)
            pupilCenterY = centerY + DIAMETER / 4;
        
        parent.fill(0);
        parent.ellipse(pupilCenterX, pupilCenterY, 10, 10);
    }
    
    /**
     * Sets the pupil direction of this eye
     * @param direction STRAIGHT_AHEAD, LEFT, RIGHT, OR DOWN
     */
    public void setPupilDirection(int direction)
    {
        if(direction != STRAIGHT_AHEAD && direction != LEFT &&
                direction != RIGHT && direction != DOWN)
            throw new IllegalArgumentException("direction must be one of STRAIGHT_AHEAD, LEFT, RIGHT, or DOWN");
        
        pupilDirection = direction;
    }
}
