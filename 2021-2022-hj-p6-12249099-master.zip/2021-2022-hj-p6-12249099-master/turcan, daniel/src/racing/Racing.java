package racing;

import processing.core.PApplet;

public class Racing extends PApplet
{

	public static void main(String[] args) {
		PApplet.main("racing.Racing");
	}

	
	
	public void settings()
	{
		size(400,600);
	}
	
	public void setup() 
	{

	}
	
	public void draw()
	{
		background(25,25,25);
	}
}
