package trafficMobile;

import processing.core.PApplet;

public class TrafficMobile extends PApplet{

	private LightMobile l1, l2;
	int click = 0;
	public static void main(String[] args) {
		PApplet.main("trafficMobile.TrafficMobile");
	}

	public void settings()
	{
		size(600, 600);
	}

	public void setup()
	{
		l1 = new LightMobile(this);
	}

	public void draw()
	{
		background(255);
		l1.drawLight(100,30);
	}
	
	public void mousePressed()
	{
		click ++;
		System.out.println("Clicks: " + click);
	}
	
}
