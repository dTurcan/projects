package trafficMobile;

import processing.core.PApplet;

public class LightMobile {
	private PApplet parent;
	
	int currentColor = 1;  
	// 1 is red
	// 2 is yellow
	// 3 is green 
	
	public LightMobile(PApplet p)
	{
		parent = p;
	}
	
	public void drawLight(int x, int y)
	{
		parent.fill(0);
		parent.rect(x,y,60,160);
		parent.fill(255);
		parent.ellipse(x+30, y + 30, 40, 40);
		parent.ellipse(x+30, y + 80, 40, 40);
		parent.ellipse(x+30, y + 130, 40, 40);
	}
	
	public void changeColor()
	{
		if (currentColor == 1)
		{		
		currentColor = 2;	
		}
		
	}
	

}
