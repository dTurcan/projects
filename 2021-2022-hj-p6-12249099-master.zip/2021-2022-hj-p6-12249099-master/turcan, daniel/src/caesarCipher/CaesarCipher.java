package caesarCipher;

import java.util.Scanner;


public class CaesarCipher {

	
	
	public static void main(String[] args) 
	{
		Scanner fromKeyboard = new Scanner(System.in);


//	    System.out.print("Messege you would like to convert:");
//		char message = fromKeyboard.nextLine().charAt(0);
//		int unicode = message;
//		
//		
//		System.out.println("How many shifts:");
//	    int shiftKey = fromKeyboard.nextInt();
//		fromKeyboard.nextLine();
		
		
		
		System.out.println(encryptWord("hello how are you", 26)); // c
		
}
	
	public static char encryptLetter(char unicode, int shiftKey)
	{
		
		int i = (int) unicode;
		
		if (i >= 65 && i <= 90)
		{
			if (i + shiftKey > 90)
			{
				unicode = (char) (unicode + shiftKey-26);
			}
			
			else unicode = (char) (unicode + shiftKey);	
		}
		
		if (i >= 97 && i <= 122)
 		{
		if (i + shiftKey > 122)
		{
				unicode = (char) (unicode + shiftKey-26);
			}
			else unicode = (char) (unicode + shiftKey);
			
	}
		
		
		char otherLetter = (char) unicode;
		return otherLetter;
	}
	
	public static String encryptWord(String word, int key)
	{
		String phrase = "";
		
		for (int i = 0; i < word.length(); i++)
		{
	   	 phrase += encryptLetter(word.charAt(i), key);
	   	 
		}
		return phrase;
		
	}
	
}