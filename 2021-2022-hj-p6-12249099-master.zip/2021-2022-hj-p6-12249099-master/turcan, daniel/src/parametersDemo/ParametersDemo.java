package parametersDemo;
	

import processing.core.PApplet;


public class ParametersDemo extends PApplet
{

	public static void main(String[] args) 
	{
		PApplet.main("parametersDemo.ParametersDemo");
	}

	
	  public void settings()
	    {
	        size(1000, 800);
	    }
	    
	    public void setup()
	    {
	        
	    }
	    
	    public void draw()
	    {
	        background(255);
	        drawSmiley(0,255, 400, 100);
	       
	        textSize(50);
	        fill(0);
	        text("First", 450, 200);
	        
	        drawSmiley(255,0, 150, 500);
	        drawSmiley(150,150, 650, 500);
	        
	    }
	    
	    public void drawSmiley(int colorRed, int colorBlue, int Xtop, int Ytop)
	    {
	       fill (colorRed, colorBlue, 0);
	       rect(Xtop,Ytop,200,200);
	       
	    }
	
	
	
	
}
