package monoalphabeticSubstitutionCipher;

import java.util.Scanner;


public class MonoalphabeticSubstitutionCipher
{

	public static void main(String[] args) 
	{
//		System.out.print("Letter: ");
//		Scanner fromKeyboard = new Scanner(System.in);	
//		char message = fromKeyboard.nextLine().charAt(0);		
//		fromKeyboard.nextLine();
		encryptLetter('a', "gkjhgfkd");
	}
	

	
	public static char encryptLetter(char letter, String key)
	{
		String alphabet = "abcdefghijklmnopqrstuvwxyz";
	    int place = alphabet.indexOf(letter);
	    
	    char answer = key.charAt(place);
	    return answer;
	}
		
}
