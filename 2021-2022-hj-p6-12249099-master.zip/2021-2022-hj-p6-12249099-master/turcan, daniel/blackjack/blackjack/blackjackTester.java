package blackjack;

public class blackjackTester {

	public static void main(String[] args) {
		
		
		//Card c = new Card("S", 1);
		//System.out.println(c.toString());	
	
	
		BlackjackUI bjui = new BlackjackUI();
		bjui.playHand();
		
	}
	
	
}
