package blackjack;

public class BlackjackUIRunner
{
	public static void main(String[] args)
	{
		BlackjackUI bjui = new BlackjackUI();
		//bjui.playHand();
		bjui.playHandsUntilQuit();
	}
}
